import java.io.*;
import java.nio.file.Files;
import java.util.*;
import org.apache.datasketches.kll.KllDoublesSketch;

/**
 * Unified evaluation for AdapQuant and three baselines:
 *   1) fixed KLL-400 (Apache DataSketches at runtime)
 *   2) Ivkin et al. 2022 Sweep-KLL Java reproduction, k=90
 *   3) official SplineSketch Java prototype, k=576
 *
 * Produces four CSV files in ./results.
 */
public class AdapQuantEvaluation {
    static final int MAX_ARCHIVED_EPOCHS = 3;
    static final int CONSOLIDATION_K = 300;
    static final int QUERY_K = 400;
    static final int KLL_BASELINE_K = 400;
    static final int IVKIN_K = 90;
    static final int SPLINE_K = 576;
    static final long BASE_SEED = 20261107L;

    enum State {
        HIGH(400), MEDIUM(200), LOW(100), CRITICAL(100);
        final int k;
        State(int k) { this.k = k; }
    }
    enum Dist { LOGNORMAL, NORMAL, UNIFORM, BURSTY }

    static class Metrics {
        double p50Rank, p90Rank, p99Rank;
        double p50Val, p90Val, p99Val;
    }

    static class Estimates {
        double q50, q90, q99;
        double queryMs;
    }

    static class AdapQuant {
        KllDoublesSketch active;
        State state;
        final List<File> archive = new ArrayList<>();
        final File dir;
        int consolidations = 0;

        AdapQuant(State initial, File dir) throws Exception {
            state = initial;
            active = KllDoublesSketch.newHeapInstance(initial.k);
            this.dir = dir;
            recreateDir(dir);
        }
        void update(double x) { active.update(x); }
        void transition(State next) throws Exception {
            if (next == state) return;
            File f = new File(dir, String.format(Locale.US, "epoch_%03d_k%d.bin", archive.size()+consolidations+1, state.k));
            Files.write(f.toPath(), active.toByteArray());
            archive.add(f);
            while (archive.size() > MAX_ARCHIVED_EPOCHS) consolidateOldestTwo();
            state = next;
            active = KllDoublesSketch.newHeapInstance(next.k);
        }
        void consolidateOldestTwo() throws Exception {
            File a = archive.remove(0), b = archive.remove(0);
            KllDoublesSketch sa = heapify(a), sb = heapify(b);
            KllDoublesSketch merged = KllDoublesSketch.newHeapInstance(CONSOLIDATION_K);
            merged.merge(sa); merged.merge(sb);
            File out = new File(dir, String.format(Locale.US, "consolidated_%03d_k%d.bin", ++consolidations, CONSOLIDATION_K));
            Files.write(out.toPath(), merged.toByteArray());
            a.delete(); b.delete();
            archive.add(0, out);
        }
        Estimates queryThree() throws Exception {
            long t0 = System.nanoTime();
            KllDoublesSketch q = KllDoublesSketch.newHeapInstance(QUERY_K);
            for (File f : archive) q.merge(heapify(f));
            q.merge(active);
            Estimates e = new Estimates();
            e.q50 = q.getQuantile(0.50);
            e.q90 = q.getQuantile(0.90);
            e.q99 = q.getQuantile(0.99);
            e.queryMs = (System.nanoTime()-t0)/1_000_000.0;
            return e;
        }
        int activeBytes() { return active.toByteArray().length; }
        long archiveBytes() { long n=0; for(File f:archive) n+=f.length(); return n; }
        int queryWorkspaceBytes() throws Exception {
            KllDoublesSketch q=KllDoublesSketch.newHeapInstance(QUERY_K);
            for(File f:archive) q.merge(heapify(f));
            q.merge(active);
            return q.toByteArray().length;
        }
    }

    public static void main(String[] args) throws Exception {
        Locale.setDefault(Locale.US);
        String mode = args.length > 0 ? args[0].toLowerCase(Locale.ROOT) : "all";
        String profile = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "quick";
        boolean paper = profile.equals("paper");
        File results = new File("results");
        if(!results.exists()) results.mkdirs();
        System.out.println("=== AdapQuant Unified Evaluation ===");
        System.out.println("Java: " + System.getProperty("java.version"));
        System.out.println("Mode="+mode+", profile="+profile);
        System.out.println("Baselines: KLL-400; Ivkin2022 Sweep reproduction k="+IVKIN_K+"; SplineSketch k="+SPLINE_K);
        System.out.println("AdapQuant: active k={400,200,100,100}, archiveMax=3, consolidationK=300, queryK=400");
        if(mode.equals("all")||mode.equals("e1")) experiment1(paper);
        if(mode.equals("all")||mode.equals("e2")) experiment2(paper);
        if(mode.equals("all")||mode.equals("e3")) experiment3(paper);
        if(mode.equals("all")||mode.equals("e4")) experiment4(paper);
        System.out.println("COMPLETE. CSV files are in: " + results.getAbsolutePath());
    }

    static void experiment1(boolean paper) throws Exception {
        int runs=paper?10:3, phaseN=100_000;
        State[] schedule={State.HIGH,State.MEDIUM,State.LOW,State.CRITICAL,State.MEDIUM,State.HIGH};
        int totalN=phaseN*schedule.length;
        try(BufferedWriter w=new BufferedWriter(new FileWriter("results/e1_overall.csv"))){
            writeHeader(w,"run,method,n");
            for(int run=1;run<=runs;run++){
                double[] data=generate(totalN,BASE_SEED+1009L*run,Dist.LOGNORMAL);
                evaluateRun(w,""+run,data,schedule,phaseN);
                System.out.println("E1 run "+run+"/"+runs+" complete");
            }
        }
    }

    static void experiment2(boolean paper) throws Exception {
        int runs=paper?10:3, phaseN=80_000;
        LinkedHashMap<String,State[]> patterns=new LinkedHashMap<>();
        patterns.put("MOSTLY_HIGH",new State[]{State.HIGH,State.HIGH,State.MEDIUM,State.HIGH,State.HIGH,State.MEDIUM});
        patterns.put("MOSTLY_LOW",new State[]{State.LOW,State.LOW,State.CRITICAL,State.LOW,State.MEDIUM,State.LOW});
        patterns.put("RAPID_CHANGE",new State[]{State.HIGH,State.LOW,State.HIGH,State.LOW,State.HIGH,State.LOW});
        patterns.put("LONG_CONSTRAINED",new State[]{State.HIGH,State.LOW,State.LOW,State.LOW,State.LOW,State.HIGH});
        patterns.put("RECOVERY",new State[]{State.HIGH,State.MEDIUM,State.LOW,State.CRITICAL,State.MEDIUM,State.HIGH});
        try(BufferedWriter w=new BufferedWriter(new FileWriter("results/e2_resource_patterns.csv"))){
            writeHeader(w,"pattern,run,method,n");
            int pi=0;
            for(Map.Entry<String,State[]> e:patterns.entrySet()){
                int totalN=phaseN*e.getValue().length;
                for(int run=1;run<=runs;run++){
                    double[] data=generate(totalN,BASE_SEED+50000L*pi+1009L*run,Dist.LOGNORMAL);
                    evaluateRun(w,e.getKey()+","+run,data,e.getValue(),phaseN);
                }
                System.out.println("E2 "+e.getKey()+" complete"); pi++;
            }
        }
    }

    static void experiment3(boolean paper) throws Exception {
        int runs=paper?10:3, phaseN=100_000;
        State[] schedule={State.HIGH,State.MEDIUM,State.LOW,State.CRITICAL,State.MEDIUM,State.HIGH};
        int totalN=phaseN*schedule.length;
        try(BufferedWriter w=new BufferedWriter(new FileWriter("results/e3_distributions.csv"))){
            writeHeader(w,"distribution,run,method,n");
            for(Dist d:Dist.values()){
                for(int run=1;run<=runs;run++){
                    double[] data=generate(totalN,BASE_SEED+100000L*d.ordinal()+1009L*run,d);
                    evaluateRun(w,d+","+run,data,schedule,phaseN);
                }
                System.out.println("E3 "+d+" complete");
            }
        }
    }

    static void experiment4(boolean paper) throws Exception {
        int runs=paper?5:2;
        int[] totals=paper?new int[]{100_000,1_000_000,5_000_000}:new int[]{100_000,1_000_000};
        State[] schedule={State.HIGH,State.MEDIUM,State.LOW,State.CRITICAL,State.MEDIUM,State.HIGH};
        try(BufferedWriter w=new BufferedWriter(new FileWriter("results/e4_scalability.csv"))){
            writeHeader(w,"total_n,run,method,n");
            for(int totalN:totals){
                int phaseN=totalN/schedule.length, actualN=phaseN*schedule.length;
                for(int run=1;run<=runs;run++){
                    double[] data=generate(actualN,BASE_SEED+actualN+1009L*run,Dist.LOGNORMAL);
                    evaluateRun(w,actualN+","+run,data,schedule,phaseN);
                }
                System.out.println("E4 N="+actualN+" complete");
            }
        }
    }

    /** Evaluates all four methods on exactly the same data. */
    static void evaluateRun(BufferedWriter w,String prefix,double[] data,State[] schedule,int phaseN) throws Exception {
        int n=data.length;
        double[] sorted=data.clone(); Arrays.sort(sorted);
        double min=sorted[0], max=sorted[n-1];

        File adir=new File("work_archive/"+prefix.replace(',','_'));
        AdapQuant aq=new AdapQuant(schedule[0],adir);
        KllDoublesSketch kll=KllDoublesSketch.newHeapInstance(KLL_BASELINE_K);
        IvkinSweepKLL ivkin=new IvkinSweepKLL(IVKIN_K,BASE_SEED+n);
        SplineSketch spline=new SplineSketch(SPLINE_K);

        long aqNs=0,kllNs=0,ivNs=0,spNs=0;
        int idx=0;
        for(int p=0;p<schedule.length;p++){
            if(p>0) aq.transition(schedule[p]);
            int end=Math.min(n,idx+phaseN);
            while(idx<end){
                double x=data[idx++];
                long t=System.nanoTime(); aq.update(x); aqNs+=System.nanoTime()-t;
                t=System.nanoTime(); kll.update(x); kllNs+=System.nanoTime()-t;
                t=System.nanoTime(); ivkin.update(x); ivNs+=System.nanoTime()-t;
                t=System.nanoTime(); spline.update(x); spNs+=System.nanoTime()-t;
            }
        }
        while(idx<n){
            double x=data[idx++];
            long t=System.nanoTime(); aq.update(x); aqNs+=System.nanoTime()-t;
            t=System.nanoTime(); kll.update(x); kllNs+=System.nanoTime()-t;
            t=System.nanoTime(); ivkin.update(x); ivNs+=System.nanoTime()-t;
            t=System.nanoTime(); spline.update(x); spNs+=System.nanoTime()-t;
        }

        Estimates ae=aq.queryThree();
        int aqQBytes=aq.queryWorkspaceBytes();
        writeMethod(w,prefix,"AdapQuant",n,aq.activeBytes(),aq.archiveBytes(),aqQBytes,"serialized",ae.queryMs,aqNs/1e6,metrics(ae,sorted));

        Estimates ke=queryKll(kll);
        writeMethod(w,prefix,"KLL-400",n,kll.toByteArray().length,0,0,"serialized",ke.queryMs,kllNs/1e6,metrics(ke,sorted));

        Estimates ie=queryIvkin(ivkin);
        writeMethod(w,prefix,"Ivkin2022-SweepKLL-Reproduction",n,ivkin.serializedSketchBytesEstimate(),0,0,"estimated_compact",ie.queryMs,ivNs/1e6,metrics(ie,sorted));

        spline.consolidate();
        Estimates se=querySpline(spline,min,max);
        writeMethod(w,prefix,"SplineSketch-official-prototype",n,spline.serializedSketchBytesUpdatable(),0,0,"official_updatable_estimate",se.queryMs,spNs/1e6,metrics(se,sorted));
    }

    static Estimates queryKll(KllDoublesSketch s){
        long t=System.nanoTime(); Estimates e=new Estimates();
        e.q50=s.getQuantile(.50); e.q90=s.getQuantile(.90); e.q99=s.getQuantile(.99);
        e.queryMs=(System.nanoTime()-t)/1e6; return e;
    }
    static Estimates queryIvkin(IvkinSweepKLL s){
        long t=System.nanoTime(); Estimates e=new Estimates();
        double[] q=s.getQuantiles(.50,.90,.99); e.q50=q[0];e.q90=q[1];e.q99=q[2];
        e.queryMs=(System.nanoTime()-t)/1e6; return e;
    }
    static Estimates querySpline(SplineSketch s,double min,double max){
        long t=System.nanoTime(); Estimates e=new Estimates();
        e.q50=splineQuantile(s,.50,min,max); e.q90=splineQuantile(s,.90,min,max); e.q99=splineQuantile(s,.99,min,max);
        e.queryMs=(System.nanoTime()-t)/1e6; return e;
    }
    static double splineQuantile(SplineSketch s,double q,double lo,double hi){
        long n=s.getN();
        if(n==0) return Double.NaN;
        for(int it=0;it<60;it++){
            double mid=lo+(hi-lo)/2.0;
            int rank=s.query(Collections.singletonList(mid)).get(0);
            double frac=rank/(double)n;
            if(frac<q) lo=mid; else hi=mid;
        }
        return lo+(hi-lo)/2.0;
    }

    static Metrics metrics(Estimates e,double[] sorted){
        Metrics m=new Metrics();
        double x50=exactQuantile(sorted,.50),x90=exactQuantile(sorted,.90),x99=exactQuantile(sorted,.99);
        m.p50Rank=rankError(sorted,e.q50,.50);m.p90Rank=rankError(sorted,e.q90,.90);m.p99Rank=rankError(sorted,e.q99,.99);
        m.p50Val=relativeError(e.q50,x50);m.p90Val=relativeError(e.q90,x90);m.p99Val=relativeError(e.q99,x99);
        return m;
    }

    static double[] generate(int n,long seed,Dist d){
        Random r=new Random(seed); double[] x=new double[n];
        for(int i=0;i<n;i++) switch(d){
            case LOGNORMAL: x[i]=Math.exp(4.5+1.05*r.nextGaussian()); if(i%1000==0)x[i]*=4.0; break;
            case NORMAL: x[i]=100+20*r.nextGaussian(); break;
            case UNIFORM: x[i]=10+990*r.nextDouble(); break;
            case BURSTY: x[i]=((i/25000)%2==0)?Math.exp(4.0+.7*r.nextGaussian()):Math.exp(5.2+1.2*r.nextGaussian()); if(i%5000==0)x[i]*=5.0; break;
        }
        return x;
    }
    static KllDoublesSketch heapify(File f) throws Exception {
        byte[] bytes = Files.readAllBytes(f.toPath());
        Class<?> memClass = Class.forName("org.apache.datasketches.memory.Memory");
        Object mem = memClass.getMethod("wrap", byte[].class).invoke(null, (Object) bytes);
        return (KllDoublesSketch) KllDoublesSketch.class.getMethod("heapify", memClass).invoke(null, mem);
    }
    static double rankError(double[] sorted,double est,double q){int idx=upperBound(sorted,est);return Math.abs(idx/(double)sorted.length-q);}
    static int upperBound(double[] a,double x){int lo=0,hi=a.length;while(lo<hi){int m=(lo+hi)>>>1;if(a[m]<=x)lo=m+1;else hi=m;}return lo;}
    static double exactQuantile(double[] a,double q){double p=q*(a.length-1);int lo=(int)Math.floor(p),hi=(int)Math.ceil(p);if(lo==hi)return a[lo];double f=p-lo;return a[lo]*(1-f)+a[hi]*f;}
    static double relativeError(double est,double exact){return exact==0?Math.abs(est):Math.abs(est-exact)/Math.abs(exact);}
    static void recreateDir(File d)throws Exception{if(d.exists())deleteRec(d);if(!d.mkdirs())throw new IOException("Could not create "+d);}
    static void deleteRec(File f)throws Exception{if(f.isDirectory()){File[] c=f.listFiles();if(c!=null)for(File x:c)deleteRec(x);}if(!f.delete())throw new IOException("Could not delete "+f);}

    static void writeHeader(BufferedWriter w,String prefix)throws Exception{
        w.write(prefix+",summary_bytes,archive_bytes,query_workspace_bytes,memory_measurement,query_ms,update_ms,p50_rank_err_pct,p90_rank_err_pct,p99_rank_err_pct,p50_value_err_pct,p90_value_err_pct,p99_value_err_pct\n");
    }
    static void writeMethod(BufferedWriter w,String prefix,String method,int n,int bytes,long archive,int qws,String memType,double qms,double ums,Metrics m)throws Exception{
        w.write(String.format(Locale.US,"%s,%s,%d,%d,%d,%d,%s,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f%n",prefix,method,n,bytes,archive,qws,memType,qms,ums,m.p50Rank*100,m.p90Rank*100,m.p99Rank*100,m.p50Val*100,m.p90Val*100,m.p99Val*100));
        w.flush();
    }
}
