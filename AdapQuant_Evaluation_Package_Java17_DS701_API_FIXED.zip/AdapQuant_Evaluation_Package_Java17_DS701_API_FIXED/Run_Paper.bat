@echo off
setlocal
cd /d "%~dp0"
if not exist results mkdir results
set LOG=results\Run_Paper.log
>"%LOG%" echo AdapQuant paper-run diagnostic log
>>"%LOG%" echo Started: %date% %time%
>>"%LOG%" echo.
java -version >>"%LOG%" 2>&1
if errorlevel 1 goto nojava
if not exist "lib\datasketches-java-7.0.1.jar" goto missing
if not exist "lib\datasketches-memory-4.1.0.jar" goto missing

echo Running PAPER experiment campaign...
java --add-modules jdk.incubator.foreign -jar AdapQuantEvaluation.jar all paper >>"%LOG%" 2>&1
set RC=%ERRORLEVEL%
if not "%RC%"=="0" goto failed

echo.
echo SUCCESS. Final CSV files are in the results folder.
echo Log: %LOG%
start "" results
pause
exit /b 0

:nojava
echo ERROR: Java was not found or could not start.
echo See %LOG%
pause
exit /b 1

:missing
echo ERROR: Missing Apache DataSketches JAR(s) in lib folder.>>"%LOG%"
echo Required: datasketches-java-7.0.1.jar and datasketches-memory-4.1.0.jar>>"%LOG%"
echo ERROR: DataSketches JARs are missing from the lib folder.
echo See %LOG%
pause
exit /b 1

:failed
echo.>>"%LOG%"
echo Java process exited with code %RC%.>>"%LOG%"
echo ERROR: Experiment failed with exit code %RC%.
echo The window will stay open. Please send me this file:
echo   %LOG%
pause
exit /b %RC%
