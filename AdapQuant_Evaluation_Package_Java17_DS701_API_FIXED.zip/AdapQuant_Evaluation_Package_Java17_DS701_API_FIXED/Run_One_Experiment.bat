@echo off
setlocal
cd /d "%~dp0"
if not exist results mkdir results
set /p EXP=Enter experiment e1, e2, e3, or e4: 
set /p PROF=Enter profile quick or paper: 
set LOG=results\Run_%EXP%_%PROF%.log
java --add-modules jdk.incubator.foreign -jar AdapQuantEvaluation.jar %EXP% %PROF% >"%LOG%" 2>&1
set RC=%ERRORLEVEL%
type "%LOG%"
echo.
echo Exit code: %RC%
echo Log saved to: %LOG%
pause
