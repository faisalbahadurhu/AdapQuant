AdapQuant Unified Evaluation Package - Java 17 build
=====================================================

IMPORTANT FIX
-------------
This package is compiled for Java 17 (class-file version 61).
The previous package was accidentally compiled for Java 21 and would fail on a Java 17 machine.

BEFORE RUNNING
--------------
Copy these two Apache DataSketches files into the lib folder:
  datasketches-java-7.0.1.jar
  datasketches-memory-4.1.0.jar

The package already contains Java-17 builds of:
  SplineSketch-official-prototype.jar
  Ivkin2022-SweepKLL-Reproduction.jar

RUNNING
-------
1. Double-click Run_Quick.bat.
2. Do NOT press a key until it reports SUCCESS or ERROR.
3. If SUCCESS, four CSV files will be created in results\.
4. If ERROR, send the generated results\Run_Quick.log file.
5. Only after Quick succeeds, run Run_Paper.bat.

Expected CSV files:
  e1_overall.csv
  e2_resource_patterns.csv
  e3_distributions.csv
  e4_scalability.csv

The batch files now save all Java output/errors in log files and keep the window open on failure.

Compatibility fix (2026-11-08): evaluator bytecode uses the Java 17 DataSketches Memory 4.1.0 interface invocation for Memory.wrap(byte[]). This fixes IncompatibleClassChangeError seen with Java 17 + datasketches-java-7.0.1 + datasketches-memory-4.1.0.

PATCH NOTE:
This evaluator was compiled against a minimal DataSketches 7.0.1 API stub so that the bytecode uses the 7.0.1 merge(KllSketch) signature exactly. The actual Apache DataSketches implementation is loaded from your runtime JARs in lib/.

NOTE:
This package contains the experimental implementation used to evaluate AdapQuant and reproduce the results reported in the paper. It includes the experiment runner, baseline implementations, workload configurations, resource-state schedules, and result-generation procedures.
The package is intended for research reproducibility rather than as a standalone software library. A separate reusable AdapQuant.jar is provided for users who want to integrate AdapQuant directly into their own Java applications.
The experiments use fixed configurations and deterministic random seeds where applicable. However, because KLL relies on randomized compaction internally, repeated executions may not always produce byte-identical sketch states or exactly identical quantile estimates. The expected outcome is statistically comparable results under the same experimental configuration.
If you use this package or AdapQuant in academic work, please cite the associated paper once the final publication details become available.
